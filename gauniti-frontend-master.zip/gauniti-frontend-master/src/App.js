import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";

// import Pages
import LandingPage from "./pages/LandingPage/LandingPage";
import GaushalaDetailPage from "./pages/GaushalaDetailPage/GaushalaDetailPage";
import RegisterPage from "./pages/AuthPages/RegisterPage";
import LoginPage from "./pages/AuthPages/LoginPage";
import ProfilePage from "./pages/ProfilePage/ProfilePage";

function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/gaushala-detail" element={<GaushalaDetailPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/login" element={<LoginPage/>} />
          <Route path="/profile" element={<ProfilePage />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
