import React, { useState, useEffect } from "react";
import "./GaushalaDetailPage.css";
import Navbar from "../../components/Navbar/Navbar";
import { Carousel } from "react-responsive-carousel";

import "react-responsive-carousel/lib/styles/carousel.min.css";
import Img1 from "./image-1.jpg";
import Img2 from "./image-2.jpg";
import FeatureButton from "../../components/FeatureButton/FeatureButton";
import DonateButton from "../../components/DonateButton/DonateButton";
import { Progress } from "antd";
import PaymentModal from "../../components/Modal/PaymentModal";

import {
  FacebookOutlined,
  TwitterOutlined,
  LinkedinOutlined,
  HeartFilled,
  TeamOutlined,
  UserOutlined,
} from "@ant-design/icons";
import Footer from "../../components/Footer/Footer";

const GaushalaDetailPage = () => {
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);

  const handlePaymentModalOpen = () => {
    setPaymentModalOpen(true);
  };
  const handlePaymentModalClose = () => {
    setPaymentModalOpen(false);
  };

  return (
    <div className="details-wrapper">
      <Navbar />
      <div className="details-container">
        <div className="details-left-container">
          <div className="details-heading">Gaushala Name</div>
          <div className="details-images">
            <Carousel showArrows={true}>
              <div>
                <img src={Img1} alt="" />
              </div>
              <div>
                <img src={Img2} alt="" />
              </div>
            </Carousel>
          </div>
          <div className="details-content-container">
            <div className="details-content-heading">About the Fundraiser</div>
            <hr />
            <div className="feature-grid">
              <FeatureButton name="Location - Roorkee" />
              <FeatureButton name="No. of Cows - 30" />
              <FeatureButton name="Size " />
              <FeatureButton name="Operating Since - 2010" />
            </div>
            <div className="details-about">
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry. Lorem Ipsum has been the industry's standard dummy text
              ever since the 1500s, when an unknown printer took a galley of
              type and scrambled Lorem Ipsum is simply dummy text of the
              printing and typesetting industry.Lorem Ipsum is simply dummy text
              of the printing and typesetting industry. Lorem Ipsum has been the
              industry's standard dummy text ever since the 1500s, when an
              unknown printer took a galley of type and scrambled Lorem Ipsum is
              simply dummy text of the printing and typesetting industry.
            </div>
          </div>
        </div>
        <div className="details-right-container">
          <div className="donate-buttons-container">
            <DonateButton onClick={handlePaymentModalOpen}>
              
                <HeartFilled />{" "}
                <span style={{ marginLeft: "8px" }}>Donate Now</span>
              
            </DonateButton>

            <PaymentModal
              open={paymentModalOpen}
              onClose={handlePaymentModalClose}
            />
            <DonateButton>
              <FacebookOutlined />{" "}
              <span style={{ marginLeft: "8px" }}>Spread the Word</span>
            </DonateButton>
            <DonateButton>
              <TwitterOutlined />{" "}
              <span style={{ marginLeft: "8px" }}>Spread the Word</span>
            </DonateButton>
            <DonateButton>
              <LinkedinOutlined />{" "}
              <span style={{ marginLeft: "8px" }}>Spread the Word</span>
            </DonateButton>
          </div>
          <div className="amount-details-container">
            <div className="amount-heading">
              <h1>Rs. 10000</h1>
              <h3>raised of Rs.20000 goal</h3>
              <div className="progress-bar">
                <Progress percent={50} showInfo={false} />
              </div>
            </div>
          </div>
          <div className="supporters-container">
            <div className="supporters-heading">
              <TeamOutlined />
              58 Supporters
            </div>
            <div className="supporters-list-container">
              <div className="supporters-list">
                <UserOutlined />
                <span>Name</span>
                <span>Amount</span>
              </div>
              <div className="supporters-list">
                <UserOutlined />
                <span>Name</span>
                <span>Amount</span>
              </div>
              <div className="supporters-list">
                <UserOutlined />
                <span>Name</span>
                <span>Amount</span>
              </div>
              <div className="supporters-list">
                <UserOutlined />
                <span>Name</span>
                <span>Amount</span>
              </div>
              <div className="supporters-list">
                <UserOutlined />
                <span>Name</span>
                <span>Amount</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer/>
    </div>
  );
};

export default GaushalaDetailPage;
