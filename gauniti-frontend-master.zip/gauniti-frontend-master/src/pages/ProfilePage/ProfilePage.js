import React from "react";
import "./ProfilePage.css";
import Navbar from "../../components/Navbar/Navbar";
import loginImg from "./loginImg.svg";
import pencilImg from "./Edit.svg";
import arrowImg from "./Expand Arrow.svg";
import Footer from "../../components/Footer/Footer";

const ProfilePage = () => {
  return (
    <div className="container">
      <Navbar />
      <div className="two-cards">
        <div className="left-card">
          <div className="image-container">
            <img src={loginImg} alt="" />
          </div>

          <div className="card-content">
            <div className="card-name">
              <h3>Dipanshi</h3>
            </div>
            <div className="card-id">
              <h4>dipanshi@gmail.com</h4>
            </div>

            <div className="card-uploadImg">
              <h4>Upload Image</h4>
            </div>

            <div className="pswd">
              <h4>Update Password?</h4>
              <div className="pswd-click">
                <h5>Click Here</h5>
              </div>
            </div>
          </div>
        </div>

        <div className="right-card">
          <div className="card-title">
            <h2>Edit Personal Details</h2>
          </div>
          <div className="mob-card">
            <div className="mob-pencil">
              <div className="mob-card-content">
                <h5>Mobile Number</h5>
              </div>
              <div className="pencil-img-container">
                <img src={pencilImg} alt="" />
              </div>
            </div>
          </div>

          <div className="verify">
            <h6>Verify</h6>
          </div>

          <div className="mob-card">
            <div className="mob-pencil">
              <div className="pan-card-content">
                <h5>Enter 10-Digit PAN Number</h5>
              </div>
              <div className="pan-pencil-img-container">
                <img src={pencilImg} alt="" />
              </div>
            </div>
          </div>

          <div className="verify">
            <h6>Verify</h6>
          </div>

          <div className="donation-card">
            <div className="donation-card-content">
              <div className="preference">
                <h4>Donation Preference</h4>
              </div>
              <div className="goal">
                <h5>Your Donation Goal</h5>
              </div>
              <div className="cost">
                <h3>Rs. 0/Yr</h3>
              </div>
            </div>
            <div className="donation-card-btn">
              <div className="btn">
                <a>Change Amount</a>
              </div>
            </div>
          </div>
          <div className="cause">
            <h5>Preferred Donation Cause</h5>
          </div>
          <div className="cause-card">
            <div className="arrow-image">
              <img src={arrowImg} alt="" />
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default ProfilePage;
