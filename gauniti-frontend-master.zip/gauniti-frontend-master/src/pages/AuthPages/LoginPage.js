import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./LoginPage.css";
import Navbar from "../../components/Navbar/Navbar";

import {
  Grid,
  Container,
  TextField,
  Button,
  InputAdornment,
  IconButton,
} from "@mui/material";

import { EyeInvisibleOutlined,EyeOutlined } from "@ant-design/icons";

import { createTheme, ThemeProvider } from "@mui/material/styles";
const theme = createTheme({
  palette: {
    primary: {
      main: "#303030",
    },
  },
});

const LoginPage = () => {
  const navigate = useNavigate();
  const [values, setValues] = useState({
    email: "",
    password: "",
    showPassword: false,
  });
  const handlePasswordVisibility = () => {
    setValues({
      ...values,
      showPassword: !values.showPassword,
    });
  };

  const handleSignUpClick = () => {
    navigate("/register");
  };
  return (
    <div className="container">
      <Navbar />
      <div className="wrapper">
        <Container maxWidth="sm">
          <Grid
            container
            spacing={2}
            direction="column"
            justifyContent="center"
            style={{ minHeight: "100vh" }}
          >
            <div className="auth-heading">LOG IN</div>

            <form>
              <Grid
                container
                direction={"column"}
                spacing={2}
                style={{ fontFamily: "Inter" }}
              >
                <Grid item>
                  <ThemeProvider theme={theme}>
                    <TextField
                      type="email"
                      fullWidth
                      label="E-mail"
                      variant="outlined"
                      primary
                      required
                      onChange={(e) =>
                        setValues({ ...values, email: e.target.value })
                      }
                    />
                  </ThemeProvider>
                </Grid>

                <Grid item>
                  <ThemeProvider theme={theme}>
                    <TextField
                      type={values.showPassword ? "text" : "password"}
                      fullWidth
                      label="Password"
                      variant="outlined"
                      primary
                      required
                      onChange={(e) =>
                        setValues({ ...values, password: e.target.value })
                      }
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <IconButton
                              onClick={handlePasswordVisibility}
                              aria-label="toggle password "
                              edge="end"
                            >
                              {values.showPassword ? (
                                <EyeOutlined />
                              ) : (
                                <EyeInvisibleOutlined />
                              )}
                            </IconButton>
                          </InputAdornment>
                        ),
                      }}
                    />
                  </ThemeProvider>
                </Grid>
                <Grid item>
                  <ThemeProvider theme={theme}>
                    <Button
                      type="submit"
                      variant="contained"
                      fullWidth
                      size="large"
                      style={{ fontFamily: "Inter" }}
                    >
                      LOG IN
                    </Button>
                  </ThemeProvider>
                </Grid>
              </Grid>
            </form>
            <div className="signup">
              Don't have an account?
              <span onClick={handleSignUpClick}>Sign Up</span>
            </div>
          </Grid>
        </Container>
      </div>
    </div>
  );
};

export default LoginPage;
