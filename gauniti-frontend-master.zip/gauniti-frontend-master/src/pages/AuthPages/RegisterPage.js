import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../../components/Navbar/Navbar";
import "./RegisterPage.css";

import {
    Grid,
    Container,
    TextField,
    Button,
    InputAdornment,
    IconButton,
  } from "@mui/material";
  
  import { EyeInvisibleOutlined,EyeOutlined } from "@ant-design/icons";
  
  import { createTheme, ThemeProvider } from "@mui/material/styles";
  const theme = createTheme({
    palette: {
      primary: {
        main: "#303030",
      },
    },
  });

const RegisterPage = () => {
    const navigate = useNavigate();
  const [values, setValues] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    showPassword: false,
  });
  const handlePasswordVisibility = () => {
    setValues({
      ...values,
      showPassword: !values.showPassword,
    });
  };
  const handleLoginClick = () => {
    navigate("/login");
  };
  return (
    <div className="container">
      <Navbar />
      <div className="wrapper">
        <Container maxWidth="sm">
          <Grid
            container
            spacing={2}
            direction="column"
            justifyContent="center"
            style={{ minHeight: "100vh" }}
          >
            <div className="heading">SIGN UP</div>

            <form >
              <Grid
                container
                direction={"column"}
                spacing={2}
                style={{ fontFamily: "Inter" }}
              >
                <Grid item>
                  <ThemeProvider theme={theme}>
                    <TextField
                      type="text"
                      fullWidth
                      label="First Name"
                      variant="outlined"
                      primary
                      required
                      onChange={(e) =>
                        setValues({ ...values, firstName: e.target.value })
                      }
                    />
                  </ThemeProvider>
                </Grid>
                <Grid item>
                  <ThemeProvider theme={theme}>
                    <TextField
                      type="text"
                      fullWidth
                      label="Last Name"
                      variant="outlined"
                      primary
                      required
                      onChange={(e) =>
                        setValues({ ...values, lastName: e.target.value })
                      }
                    />
                  </ThemeProvider>
                </Grid>
                <Grid item>
                  <ThemeProvider theme={theme}>
                    <TextField
                      type="email"
                      fullWidth
                      label="E-mail"
                      variant="outlined"
                      primary
                      required
                      onChange={(e) =>
                        setValues({ ...values, email: e.target.value })
                      }
                    />
                  </ThemeProvider>
                </Grid>

                <Grid item>
                  <ThemeProvider theme={theme}>
                    <TextField
                      type={values.showPassword ? "text" : "password"}
                      fullWidth
                      label="Password"
                      variant="outlined"
                      primary
                      required
                      onChange={(e) =>
                        setValues({ ...values, password: e.target.value })
                      }
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <IconButton
                              onClick={handlePasswordVisibility}
                              aria-label="toggle password "
                              edge="end"
                            >
                              {values.showPassword ? (
                                <EyeOutlined />
                              ) : (
                                <EyeInvisibleOutlined />
                              )}
                            </IconButton>
                          </InputAdornment>
                        ),
                      }}
                    />
                  </ThemeProvider>
                </Grid>
                <Grid item>
                  <ThemeProvider theme={theme}>
                    <Button
                      type="submit"
                      variant="contained"
                      fullWidth
                      size="large"
                      style={{ fontFamily: "Inter" }}
                    >
                      CREATE ACCOUNT
                    </Button>
                  </ThemeProvider>
                </Grid>
              </Grid>
            </form>
            <div className="login">
              Already have an account?
              <span onClick={handleLoginClick}>Login</span>
            </div>
          </Grid>
        </Container>
      </div>
    </div>
  );
};

export default RegisterPage;
