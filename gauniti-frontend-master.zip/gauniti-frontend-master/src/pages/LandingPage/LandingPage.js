import React from "react";
import "./LandingPage.css";
import Navbar from "../../components/Navbar/Navbar";
import bannerImg from "./image 6.png";
import { Select } from "antd";
import Cards from "../../components/Cards/Cards";
import Footer from "../../components/Footer/Footer";

const handleChange = (value) => {
  console.log(`selected ${value}`);
};
const options = [
  {
    label: "Uttarakhand",
    value: "uttarakhand",
  },
  {
    label: "Bihar",
    value: "bihar",
  },
  {
    label: "Maharastra",
    value: "maharastra",
  },
];

const LandingPage = () => {
  return (
    <div className="container">
      <Navbar />
      <div className="banner">
        <div className="banner-image-container">
          <img src={bannerImg} alt="" />
        </div>
        <div className="banner-content-container">
          <h1>Make Your Gaudaan Today</h1>
          <h3>0% PLATFORM FEE</h3>
        </div>
      </div>

      <div className="explore-container">
        <div className="filter-container">
          <div className="filter-box">
            <div className="heading">CATEGORIES</div>
            <hr />
            <div className="properties">
              <Select
                mode="multiple"
                style={{
                  width: "100%",
                  color: "#000",
                  margin: "6px 0",
                }}
                placeholder="Location"
                size="large"
                onChange={handleChange}
                options={options}
              />
              <Select
                mode="multiple"
                style={{
                  width: "100%",
                  color: "#000",
                  margin: "6px 0",
                }}
                placeholder="Price"
                size="large"
                onChange={handleChange}
                options={options}
              />
              <Select
                mode="multiple"
                style={{
                  width: "100%",
                  color: "#000",
                  margin: "6px 0",
                }}
                placeholder="No of Cows"
                size="large"
                onChange={handleChange}
                options={options}
              />
              <Select
                mode="multiple"
                style={{
                  width: "100%",
                  borderColor:"#000",
                  margin: "6px 0",
                }}
                placeholder="Tax Status"
                size="large"
                onChange={handleChange}
                options={options}
               
              />
            </div>
          </div>
        </div>
        <div className="cards-container">
          <div className="cards-grid">
            <Cards/>
            <Cards/>
            <Cards/>
            <Cards/>
            <Cards/>

          </div>
        </div>
      </div>
      <Footer/>
    </div>
  );
};

export default LandingPage;
