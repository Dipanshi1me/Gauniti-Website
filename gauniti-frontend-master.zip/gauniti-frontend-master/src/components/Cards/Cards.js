import React from 'react';

import { useNavigate } from "react-router-dom";
import "./Cards.css"
import CardImg from "./cardImg.png"
import { Progress } from 'antd';

const Cards = () => {
    const navigate = useNavigate();
    const handleGaushalaClick = () => {
        navigate("/gaushala-detail");
    };
  return (
    <div className='card-container' onClick={handleGaushalaClick}>
        <div className='image-container'>
            <img src={CardImg} alt="" />

        </div>
        <div className='card-content'>
            <div className='card-name card-heading'>
                Gaushala Name
            </div>
            <div className='card-amount card-heading'>
                Rs.1000 <span>raised</span>
            </div>
            <div className='card-time card-heading'>
            10 <span>Days Left</span>
            </div>
            <div className='progress-bar'>
            <Progress percent={50} showInfo={false} />
            </div>

            <div className='buttons'>
                <div className='button'>
                    Roorkee
                </div>
                <div className='button button-clickable'>
                    Donate
                </div>

            </div>
        </div>
    </div>
  )
}

export default Cards