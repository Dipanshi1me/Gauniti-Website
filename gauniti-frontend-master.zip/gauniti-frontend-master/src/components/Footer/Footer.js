import React from "react";
import "./Footer.css";
import {
  FacebookOutlined,
  TwitterOutlined,
  LinkedinOutlined,
} from "@ant-design/icons";

const Footer = () => {
  return (
    <div className="footer-wrapper">
      <div className="footer-left-container">
        <div className="footer-contact-heading">Gauniti</div>
        <div className="footer-followers">
          <h1>....M+</h1>
          <h4>followers</h4>
        </div>
        <div className="footer-contact-content">
          <h3>
            For any queries
            <br />
            Email: @
            <br />
            Contact No.:
          </h3>
        </div>
      </div>
      <div className="footer-middle-container">
        <div className="footer-contact-heading">About Us</div>
        <div className="footer-about-content">
          <h3>
            Gauniti is a platform where you can make your gaudaan and help the
            needy people. We do not charge any platform fee. We are here to help
            you.
          </h3>
        </div>
      </div>
      <div className="footer-right-container">
        <div className="footer-contact-heading">Support</div>
        <div className="footer-links">
          <FacebookOutlined  style={{fontSize:"32px" , marginRight:"12px"}}/>
          <TwitterOutlined style={{fontSize:"32px", marginRight:"12px"}}/>
          <LinkedinOutlined style={{fontSize:"32px", marginRight:"12px"}}/>
        </div>
      </div>
    </div>
  );
};

export default Footer;
