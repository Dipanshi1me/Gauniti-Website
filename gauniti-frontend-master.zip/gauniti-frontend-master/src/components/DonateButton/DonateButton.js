import React from 'react';
import "./DonateButton.css"

const DonateButton = ({children,onClick}) => {
  return (
    <div className='donate-button-wrapper' onClick={onClick}>{children}</div>
  )
}

export default DonateButton