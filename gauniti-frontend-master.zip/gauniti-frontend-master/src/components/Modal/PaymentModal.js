import React, { useState, useEffect } from "react";
import "./PaymentModal.css";
import { Modal, Fade, Backdrop, Box, TextField } from "@mui/material";
import {
  ArrowRightOutlined,
  CloseOutlined,
  LeftOutlined,
  HeartFilled
} from "@ant-design/icons";
//mui modal style
const style = {
  position: "absolute",
  top: "30%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: "40%",
  borderRadius: "16px",
  border: "2px solid #000",
  boxShadow: 24,
  height: "fit-content",
  paddingBottom: "16px",
  bgcolor: "background.paper",
};

const PaymentModal = ({ open, onClose }) => {
  const [verification, setVerification] = useState(false);

  const handleModalContinue = () => {
    setVerification(true);
  };
  const handleModalBack = () => {
    setVerification(false);
  };

  return (
    <>
      <Modal
        open={open}
        onClose={onClose}
        closeAfterTransition
        slots={{ backdrop: Backdrop }}
        slotProps={{
          backdrop: {
            timeout: 500,
          },
        }}
      >
        <Fade in={open}>
          <Box sx={style}>
            {!verification ? (
              <>
                <div className="modal-nav">
                  <div className="modal-title">Verification</div>
                  <div className="modal-close" onClick={onClose}>
                    <CloseOutlined></CloseOutlined>
                  </div>
                </div>
                <div className="modal-content">
                  <TextField
                    required
                    id="outlined-required"
                    label="Mobile Number"
                    variant="outlined"
                    fullWidth
                    sx={{ margin: "12px 0" }}
                  />
                  <div className="field-verify">Verify</div>
                  <TextField
                    required
                    id="outlined-required"
                    label="Enter 10 digit PAN number "
                    variant="outlined"
                    fullWidth
                    sx={{ margin: "12px 0" }}
                  />
                  <div className="field-verify">Verify</div>
                </div>
                <div className="button-container">
                  <button
                    className="modal-continue-button"
                    onClick={handleModalContinue}
                  >
                    <span>Continue</span> <ArrowRightOutlined />
                  </button>
                </div>
              </>
            ) : (
              <>
                <div className="modal-nav">
                  <div className="modal-back" onClick={handleModalBack}>
                    <LeftOutlined />
                  </div>
                  <div className="modal-title">Choose a Donation Amount</div>
                  <div className="modal-close" onClick={onClose}>
                    <CloseOutlined></CloseOutlined>
                  </div>
                </div>
                <div className="modal-content">
                  <div className="default-amount-container">
                    <div className="default-amount">Rs. 100</div>
                    <div className="default-amount">Rs. 500</div>
                    <div className="default-amount">Rs. 1000</div>
                    <div className="default-amount">Rs. 5000</div>
                  </div>
                  <div className="modal-text">Or Donate Any Other Amount</div>
                </div>
                <div className="modal-input-container">
                  <TextField
                    required
                    id="outlined-required"
                    label="Amount"
                    variant="outlined"
                    fullWidth
                    sx={{ margin: "12px 0" }}
                  />
                </div>
                <div className="modal-checkbox">
                  <input type="checkbox" name="anonymous" id="anonymous" />
                  <label for="anonymous">Make my donation anonymous</label>
                </div>
                <div className="button-container">
                  <button
                    className="modal-continue-button"
                    
                  >
                    <HeartFilled /><span>Donate</span> 
                  </button>
                </div>
              </>
            )}
          </Box>
        </Fade>
      </Modal>
    </>
  );
};

export default PaymentModal;
