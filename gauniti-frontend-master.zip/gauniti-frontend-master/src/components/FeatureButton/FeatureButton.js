import React from 'react';
import "./FeatureButton.css"


const FeatureButton = (props) => {
  return (
    <div className='feature-button-container'>
        {props.name}
    </div>
  )
}

export default FeatureButton