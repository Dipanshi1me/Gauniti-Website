import React from "react";

import { useNavigate } from "react-router-dom";
import "./Navbar.css";
import Logo from "./Logo.svg";
import { UserOutlined, SearchOutlined } from "@ant-design/icons";

const Navbar = () => {
  const navigate = useNavigate();
  const handleLogoClick = () => {
    navigate("/");
  };
  const handleProfileClick = () => {
    navigate("/login");
  };
  return (
    <div className="navbar">
      <div className="logo-container" onCLick={handleLogoClick}>
        <img src={Logo} alt="" className="logo" onCLick={handleLogoClick}/>
        <div >
          Gauniti
        </div>
      </div>
      <ul onCLick={handleLogoClick}>
        <li >Home</li>
      </ul>
      <div className="search-box">
        <input type="text" placeholder="Search" />
        <SearchOutlined className="search-icon"/>
      </div>

      <div className="user-container" onClick={handleProfileClick}>
        <UserOutlined className="user-icon"/>
      </div>
    </div>
  );
};

export default Navbar;
